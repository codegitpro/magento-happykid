Use this code to display special product block on homepage.{{block class="Ortho\Specialproduct\Block\Listhome" name="special_product" template="Ortho_Specialproduct::list_home.phtml"}}



<referenceContainer name="sidebar.additional">
			<block class="Ortho\Specialproduct\Block\Listhome" name="left.banner" template="Ortho_Specialproduct::list_home.phtml" />
		</referenceContainer>