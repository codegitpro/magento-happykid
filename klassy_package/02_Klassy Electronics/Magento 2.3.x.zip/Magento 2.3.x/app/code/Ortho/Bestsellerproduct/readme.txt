Use this code to display bestseller product block on homepage.{{block class="Ortho\Bestsellerproduct\Block\Listhome" name="bestseller_product" template="Ortho_Bestsellerproduct::list_home.phtml"}}



<referenceContainer name="sidebar.additional">
			<block class="Ortho\Bestsellerproduct\Block\Listhome" name="left.banner" template="Ortho_Bestsellerproduct::list_home.phtml" />
		</referenceContainer>