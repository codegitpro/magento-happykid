Use this code to display new product block on homepage.{{block class="Ortho\Newproduct\Block\Listhome" name="new_product" template="Ortho_Newproduct::list_home.phtml"}}



<referenceContainer name="sidebar.additional">
			<block class="Ortho\Newproduct\Block\Listhome" name="left.banner" template="Ortho_Newproduct::list_home.phtml" />
		</referenceContainer>