Use this code to display featured product block on homepage.{{block class="Ortho\Featuredproduct\Block\Listhome" name="featured_product" template="Ortho_Featuredproduct::list_home.phtml"}}



<referenceContainer name="sidebar.additional">
			<block class="Ortho\Featuredproduct\Block\Listhome" name="left.banner" template="Ortho_Featuredproduct::list_home.phtml" />
		</referenceContainer>